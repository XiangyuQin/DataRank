﻿# -*- coding:utf-8 -*-

'''
    writer:XiangyuQIn
'''
import random
import config
import common
import simplejson
import re
import time
import datetime
from MysqlService import MysqlService
from RedisService import RedisService
from MongoService import MongoService
from Log import Log

class Application(object):
    
    def __init__(self):
        self.now = datetime.datetime.now()
        self.log = Log(self.now)
        self.type_dict = {}
        self.typeNum = {}

    def run(self):
        nowStr=common.datetime_toStringYMDHMS(self.now)
        self.log.printInfo("program start,now:%s" %(nowStr))
        mysqlArticles, redisArticles, self.typeNum = self.loadData()
        if (len(redisArticles) and len(mysqlArticles) > 0):
            processedArticles=self.handleArticles(mysqlArticles, redisArticles)
            self.outputData(processedArticles)
        self.log.printInfo("program end,now:%s" %(nowStr))


    def loadData(self):
        '''load datas from mysql and redis
    
        returns:
            articles:the program is going to handle these program
        '''
        self.log.printInfo("loadData start")
        mysqlArticles = self.loadArticlesFromMysql()
        redisArticles = self.loadArticlesFromRedis()
        typeNum = self.loadtypeNumFromMysql()
        self.type_dict = self.loadTypeFromRedis()
        self.log.printInfo("mysqlArticles:%d" %(len(mysqlArticles)))
        self.log.printInfo("redisArticles:%d" %(len(redisArticles)))
        self.log.printInfo("loadData end")
        return mysqlArticles, redisArticles, typeNum
        

    def loadtypeNumFromMysql(self):
        typeNum = MysqlService(self.log)
        typeNum = service.getTypeNum()
        return typeNum
    
    def loadArticlesFromMysql(self):
        service = MysqlService(self.log)
        articles = service.getArticles()
        return articles
        
    def loadArticlesFromRedis(self):
        service = RedisService(self.log)
        articles = service.hgetArticles()
        return articles
        
    def loadTypeFromRedis(self):
        service = RedisService(self.log)
        type_dict = service.hgetArticlesType()
        return type_dict
        
    def handleArticles(self, mysqlArticles, redisArticles):
        articles = self.mergeArticles(mysqlArticles, redisArticles)
        articles = self.articlesFilter(articles)
        articles = self.setAttribute(articles)
        articles = self.rankArticles(articles)
        processedArticles = self.setTopArticles(articles)
        return processedArticles
    
    def articlesFilter(self, articles):
        clearArticles = []
        for article in articles:
            if (article["illustration_status"]==config.illustrationStatus["outer"]):
                continue
            clearArticles.append(article)  
        return clearArticles
    
    def setAttribute(self, articles):
        for article in articles:
            type = article["type"]
            article["type_id"] = self.type_dict[type]
        return articles
    
    def setTopArticles(self, articles):
        for article in articles:
            if article["illustration_status"]==config.illustrationStatus["noPic"] && article["hunman"]==config.humanMark["excellent"]:
                article["type_id"] = self.type_dict["jingpin"]
            else:
                article["type_id"] = self.type_dict["tuijian"]
        return articles
        
    def mergeArticles(self, mysqlArticles, redisArticles):
        articles=[]
        count=0
        for mysqlArticle in mysqlArticles:
            if redisArticles.has_key(str(mysqlArticle['id'])):
                dict_redisArticles = eval(redisArticles[str(mysqlArticle['id'])])
                article = common.mergeDict(dict_redisArticles,mysqlArticle)
                article["hunman"] = random.choice(config.testHunmanMark)
                articles.append(article)
            else:
                self.log.printWarning("mysqlArticle['id']:%s" %(mysqlArticle['id']))
        return articles
        
    def rankArticles(self, articles):
        count=0
        num = len(articles)
        for article in articles:
            humanMark = article["hunman"]*0.25*0.5
            illustrationMark = (3-article["illustration_status"])*0.5*0.2
            type = article["type"]
            typeMark = (1-float(self.typeNum[type])/num)*0.3
            rankingScore=1-(count/float(num))
            count = count+1
            article['rankingScore']=rankingScore*0.5+(humanMark+illustrationMark+typeMark)*0.5
        return articles
        
    def outputData(self, articles):
        preparedArticles = self.generateArticles(articles)
        mark = self.getMark()
        self.removeArticles(mark)
        self.outputArticles(preparedArticles, mark)
        self.updateMark(mark)
        self.log.printInfo("outputData end")
    
    def generateArticles(self, articles):
        preparedArticles = []
        for article in articles:
            preparedArticle = self.generateArticle(article)
            preparedArticles.append(preparedArticle)
        return preparedArticles
        
    def generateArticle(self, article):
        preparedArticle={}
        preparedArticle["content"] = article["content"]
        preparedArticle["writer"] = article["writer"]
        preparedArticle["rankingScore"] = article["rankingScore"]
        preparedArticle["title"] = article["title"]
        preparedArticle["date"] = article["date"]
        preparedArticle["image"] = article["image"]
        preparedArticle["type_id"] =  article["type_id"]
        preparedArticle["id"] = article["id"]
        preparedArticle["brief"] = article["brief"]
        return preparedArticle
        
    def getMark(self):
        service = RedisService(self.log)
        redisMark = service.getArticlesMark()
        if redisMark==None or redisMark=="" or redisMark=="B":
            mark="A"
        else:
            mark="B"
        return mark
        
    def removeArticles(self, mark):
        service = MongoService(self.log)
        service.remove(mark)
        
    def outputArticles(self, articles, mark):
        self.log.printInfo("outputArticles: %d" %(len(articles))) 
        service = MongoService(self.log)
        service.setArticles(articles, mark)

    def updateMark(self, mark):
        service = RedisService(self.log)
        service.updateMark(mark)
	
if __name__ == '__main__':
    application = Application()
    application.run()
