﻿# -*- coding: UTF-8 -*-
import redis
import common
import datetime
from Log import Log

class RedisService(object):
    def __init__(self, log):
        self.log = log
        self.r = redis.Redis(host='localhost', port=6379, db=0)
        
        
    def hgetArticles(self):
        try:
            articles = self.r.hgetall("articles")
            return articles
        except Exception as e:
            self.log.printError("hgetArticles: %s" % (e))
            return {}
            
    def getArticlesMark(self):
        try:
            mark = self.r.get("rankMark")
            return mark
        except Exception as e:
            self.log.printError("getArticlesMark: %s" % (e))
            return ""
            
    def updateMark(self, mark):
        try:
            mark = self.r.set("rankMark", mark)
        except Exception as e:
            self.log.printError("updateMark: %s" % (e))
        

if __name__ == '__main__':
    now=datetime.datetime.now()
    log = Log(now)
    service = RedisService(log)
    dict =service.hgetArticles()
    print len(dict)
    print type(dict)
    