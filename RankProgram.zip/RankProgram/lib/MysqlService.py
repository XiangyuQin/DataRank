# -*- coding: UTF-8 -*-

import MySQLdb
import common
import config
import datetime
import MySQLdb.cursors
from Log import Log

class MysqlService(object):
    def __init__(self, log):
        self.log = log
        self.db = MySQLdb.connect("localhost","root", "qinxiangyu", "spider",charset='utf8', cursorclass = MySQLdb.cursors.DictCursor)

    def getArticles(self):
        cursor = self.db.cursor()
        sql = "SELECT * FROM articles ORDER BY date desc"
        try:
            cursor.execute(sql)
            results = cursor.fetchall()
            '''
            for row in results:
                print common.datetime_toString(row['editdate'])
            '''
            return results
        except Exception as e:
            self.log.printError("getArticles: %s" % (e))
            return []
    
    def getTypeNum(self):
        result_dict = {}
        cursor = self.db.cursor()
        sql = "select type, count(type) as number FROM articles GROUP BY type"
        try:
            cursor.execute(sql)
            results = cursor.fetchall()
            for result in results:
                result_dict[result["type"]]=result["number"]
            '''
            for row in results:
                print common.datetime_toString(row['editdate'])
            '''
        except Exception as e:
            self.log.printError("getArticles: %s" % (e))
        return result_dict
            
    def closeDb(self):
        self.db.close()
    

if __name__ == '__main__':
    now=datetime.datetime.now()
    log = Log(now)
    service = MysqlService(log)
    list = service.getArticles()
    print len(list)
    if(len(list)>0):
        print list[0]