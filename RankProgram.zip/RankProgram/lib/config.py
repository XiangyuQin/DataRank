﻿# -*- coding: UTF-8 -*-
logSrc="logs/"
logMaxBytes=10*1024*1024
logBackupCount=5
pptThemes=["2","3","4"]
weChatType=["0","1"]
testHunmanMark=[3, 4]
humanMark={"noShow":0, "zhuanzai":1, "qualified":2, "good":3, "excellent":4}
illustrationStatus={"noPic":1, "internal":2, "outer":3}