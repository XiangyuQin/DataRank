﻿# -*- coding: UTF-8 -*-
logSrc="logs/"
logMaxBytes=10*1024*1024
logBackupCount=5