# -*- coding: UTF-8 -*-
import pymongo
import common
from Log import Log
from pymongo import MongoClient

class MongoService(object):
    def __init__(self, log):
        self.log = log
        conn = MongoClient("localhost", 27017)
        self.db = conn["webSite"]

    def setArticles(self, articles, mark):
        try:
            cursor = self.getCursor(mark)
            information_id = cursor.insert(articles)
            self.log.printInfo("articles: %d, mark:%s" % (len(articles), mark))
        except Exception as e:
            self.log.printError("setArticles: %s" % (e))
        
    
    def remove(self, mark):
        try:
            cursor = self.getCursor(mark)
            information_id = cursor.remove({})
            print "remove information:%d, mark:%s" %(len(information_id), mark)
        except Exception as e:
            self.log.printError("remove: %s" % (e))
        
    def getCursor(self, mark):
        if mark=="A":
            cursor = self.db.articlesA
        else:
            cursor = self.db.articlesB
        return cursor
        
if __name__ == '__main__':
    now=datetime.datetime.now()
    log = Log(now)
    service = MongoService()
    dict =service.setArticles()
    print len(dict)
    print type(dict)

